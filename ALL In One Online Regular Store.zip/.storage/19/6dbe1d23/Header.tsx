import { useState, useEffect } from 'react';
import { ShoppingCart, Search, Menu, User, Globe, Store } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getCart, getLanguage, setLanguage, type Language } from '@/lib/store';
import Cart from './Cart';

interface HeaderProps {
  onSearch: (query: string) => void;
  onCategoryFilter: (categoryId: string) => void;
}

const translations = {
  en: {
    storeName: 'ALL In One Online Regular Store',
    storeTagline: 'Your Complete Shopping Destination',
    search: 'Search products...',
    admin: 'Admin Panel',
    cart: 'Cart',
    language: 'Language'
  },
  bn: {
    storeName: 'অল ইন ওয়ান অনলাইন রেগুলার স্টোর',
    storeTagline: 'আপনার সম্পূর্ণ কেনাকাটার গন্তব্য',
    search: 'পণ্য খুঁজুন...',
    admin: 'অ্যাডমিন প্যানেল',
    cart: 'কার্ট',
    language: 'ভাষা'
  }
};

export default function Header({ onSearch, onCategoryFilter }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [cartItemCount, setCartItemCount] = useState(0);
  const [language, setCurrentLanguage] = useState<Language>(getLanguage());
  const [isCartOpen, setIsCartOpen] = useState(false);

  const t = translations[language];

  useEffect(() => {
    const updateCartCount = () => {
      const cart = getCart();
      const count = cart.reduce((total, item) => total + item.quantity, 0);
      setCartItemCount(count);
    };

    updateCartCount();
    
    // Listen for cart updates
    const handleStorageChange = () => updateCartCount();
    window.addEventListener('storage', handleStorageChange);
    
    // Custom event for same-tab updates
    window.addEventListener('cartUpdated', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('cartUpdated', handleStorageChange);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setCurrentLanguage(newLanguage);
    window.location.reload(); // Reload to update all components
  };

  const navigateToAdmin = () => {
    window.location.href = '/admin';
  };

  return (
    <header className="bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 shadow-xl border-b-4 border-gold-400">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between gap-4">
          {/* Enhanced Logo */}
          <div className="flex items-center gap-4">
            <div className="relative group">
              {/* Main Logo Container */}
              <div className="w-16 h-16 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-2xl flex items-center justify-center shadow-2xl transform transition-all duration-300 group-hover:scale-110 group-hover:rotate-3">
                {/* Inner Logo Design */}
                <div className="w-12 h-12 bg-white rounded-xl flex items-center justify-center shadow-inner">
                  <Store className="w-8 h-8 text-blue-600" />
                </div>
                {/* Decorative Elements */}
                <div className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-300 rounded-full animate-pulse"></div>
                <div className="absolute -bottom-1 -left-1 w-3 h-3 bg-pink-400 rounded-full animate-bounce"></div>
              </div>
              {/* Glow Effect */}
              <div className="absolute inset-0 w-16 h-16 bg-gradient-to-br from-yellow-400 via-orange-500 to-red-500 rounded-2xl opacity-20 blur-lg animate-pulse"></div>
            </div>
            
            <div className="text-white">
              <h1 className="text-2xl md:text-3xl font-bold bg-gradient-to-r from-yellow-200 to-white bg-clip-text text-transparent hidden md:block leading-tight">
                {t.storeName}
              </h1>
              <h1 className="text-xl font-bold bg-gradient-to-r from-yellow-200 to-white bg-clip-text text-transparent md:hidden">
                ALL In One
              </h1>
              <p className="text-sm text-blue-100 opacity-90 hidden md:block">
                {t.storeTagline}
              </p>
            </div>
          </div>

          {/* Enhanced Search Bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-md mx-4">
            <div className="relative group">
              <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5 transition-colors group-focus-within:text-blue-500" />
              <Input
                type="text"
                placeholder={t.search}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-12 pr-4 py-3 bg-white/95 backdrop-blur-sm border-2 border-white/20 rounded-xl shadow-lg focus:border-yellow-400 focus:ring-2 focus:ring-yellow-200 transition-all duration-300"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-blue-400/10 to-purple-400/10 rounded-xl opacity-0 group-focus-within:opacity-100 transition-opacity duration-300 pointer-events-none"></div>
            </div>
          </form>

          {/* Enhanced Actions */}
          <div className="flex items-center gap-3">
            {/* Language Selector */}
            <div className="relative">
              <Select value={language} onValueChange={handleLanguageChange}>
                <SelectTrigger className="w-28 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 transition-all duration-300">
                  <Globe className="w-4 h-4 mr-2" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">🇺🇸 EN</SelectItem>
                  <SelectItem value="bn">🇧🇩 বাং</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Admin Button */}
            <Button
              variant="secondary"
              size="sm"
              onClick={navigateToAdmin}
              className="hidden md:flex items-center gap-2 bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20 transition-all duration-300"
            >
              <User className="w-4 h-4" />
              {t.admin}
            </Button>

            {/* Enhanced Cart */}
            <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
              <SheetTrigger asChild>
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="relative bg-gradient-to-r from-yellow-400 to-orange-500 text-white hover:from-yellow-500 hover:to-orange-600 shadow-lg transform transition-all duration-300 hover:scale-105"
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span className="hidden md:inline ml-2 font-semibold">{t.cart}</span>
                  {cartItemCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-2 -right-2 w-6 h-6 rounded-full p-0 flex items-center justify-center text-xs font-bold bg-red-500 animate-pulse"
                    >
                      {cartItemCount}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <Cart onClose={() => setIsCartOpen(false)} />
              </SheetContent>
            </Sheet>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button 
                  variant="secondary" 
                  size="sm" 
                  className="md:hidden bg-white/10 backdrop-blur-sm border-white/20 text-white hover:bg-white/20"
                >
                  <Menu className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-4 mt-8">
                  <Button
                    variant="outline"
                    onClick={navigateToAdmin}
                    className="flex items-center gap-2 justify-start"
                  >
                    <User className="w-4 h-4" />
                    {t.admin}
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
      
      {/* Decorative Bottom Border */}
      <div className="h-1 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500"></div>
    </header>
  );
}