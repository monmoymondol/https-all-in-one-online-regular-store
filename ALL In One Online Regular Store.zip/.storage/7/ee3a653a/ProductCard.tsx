import { useState } from 'react';
import { ShoppingCart, Plus } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { toast } from 'sonner';
import { addToCart, formatPrice, getLanguage, type Product, type Language } from '@/lib/store';

interface ProductCardProps {
  product: Product;
  categoryName: string;
}

const translations = {
  en: {
    addToCart: 'Add to Cart',
    outOfStock: 'Out of Stock',
    inStock: 'In Stock',
    added: 'Added to cart!'
  },
  bn: {
    addToCart: 'কার্টে যোগ করুন',
    outOfStock: 'স্টক নেই',
    inStock: 'স্টকে আছে',
    added: 'কার্টে যোগ করা হয়েছে!'
  }
};

export default function ProductCard({ product, categoryName }: ProductCardProps) {
  const [isLoading, setIsLoading] = useState(false);
  const language: Language = getLanguage();
  const t = translations[language];

  const handleAddToCart = async () => {
    if (product.stock <= 0) return;
    
    setIsLoading(true);
    
    try {
      addToCart(product.id, 1);
      toast.success(t.added);
      
      // Dispatch custom event to update cart count
      window.dispatchEvent(new CustomEvent('cartUpdated'));
    } catch (error) {
      toast.error('Error adding to cart');
    } finally {
      setIsLoading(false);
    }
  };

  const productName = language === 'en' ? product.name_en : product.name_bn;
  const productDescription = language === 'en' ? product.description_en : product.description_bn;
  const isOutOfStock = product.stock <= 0;

  return (
    <Card className="group hover:shadow-lg transition-all duration-300 hover:-translate-y-1">
      <CardContent className="p-0">
        <div className="relative overflow-hidden rounded-t-lg">
          <img
            src={product.image}
            alt={productName}
            className="w-full h-48 object-cover group-hover:scale-105 transition-transform duration-300"
            onError={(e) => {
              const target = e.target as HTMLImageElement;
              target.src = 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400&h=300&fit=crop';
            }}
          />
          {isOutOfStock && (
            <div className="absolute inset-0 bg-black bg-opacity-50 flex items-center justify-center">
              <Badge variant="destructive" className="text-sm">
                {t.outOfStock}
              </Badge>
            </div>
          )}
          <Badge 
            variant="secondary" 
            className="absolute top-2 left-2 text-xs"
          >
            {categoryName}
          </Badge>
        </div>
        
        <div className="p-4">
          <h3 className="font-semibold text-lg text-gray-900 mb-2 line-clamp-1">
            {productName}
          </h3>
          <p className="text-gray-600 text-sm mb-3 line-clamp-2">
            {productDescription}
          </p>
          
          <div className="flex items-center justify-between mb-3">
            <span className="text-2xl font-bold text-blue-600">
              {formatPrice(product.price)}
            </span>
            <Badge 
              variant={isOutOfStock ? "destructive" : "secondary"}
              className="text-xs"
            >
              {isOutOfStock ? t.outOfStock : `${product.stock} ${t.inStock}`}
            </Badge>
          </div>
        </div>
      </CardContent>
      
      <CardFooter className="p-4 pt-0">
        <Button
          onClick={handleAddToCart}
          disabled={isOutOfStock || isLoading}
          className="w-full"
          size="sm"
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Adding...
            </div>
          ) : (
            <div className="flex items-center gap-2">
              <ShoppingCart className="w-4 h-4" />
              {t.addToCart}
            </div>
          )}
        </Button>
      </CardFooter>
    </Card>
  );
}