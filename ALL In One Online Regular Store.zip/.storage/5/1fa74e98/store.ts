// Data types
export interface Category {
  id: string;
  name_en: string;
  name_bn: string;
}

export interface Product {
  id: string;
  name_en: string;
  name_bn: string;
  description_en: string;
  description_bn: string;
  price: number;
  category_id: string;
  image: string;
  stock: number;
}

export interface CartItem {
  product_id: string;
  quantity: number;
}

export type Language = 'en' | 'bn';

// Default data
const defaultCategories: Category[] = [
  { id: '1', name_en: 'Electronics', name_bn: 'ইলেকট্রনিক্স' },
  { id: '2', name_en: 'Clothing', name_bn: 'পোশাক' },
  { id: '3', name_en: 'Home & Garden', name_bn: 'ঘর ও বাগান' },
  { id: '4', name_en: 'Books', name_bn: 'বই' },
  { id: '5', name_en: 'Sports', name_bn: 'খেলাধুলা' }
];

const defaultProducts: Product[] = [
  {
    id: '1',
    name_en: 'Smartphone',
    name_bn: 'স্মার্টফোন',
    description_en: 'Latest Android smartphone with great features',
    description_bn: 'দুর্দান্ত বৈশিষ্ট্য সহ সর্বশেষ অ্যান্ড্রয়েড স্মার্টফোন',
    price: 25000,
    category_id: '1',
    image: 'https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=400',
    stock: 50
  },
  {
    id: '2',
    name_en: 'T-Shirt',
    name_bn: 'টি-শার্ট',
    description_en: 'Comfortable cotton t-shirt',
    description_bn: 'আরামদায়ক সুতির টি-শার্ট',
    price: 800,
    category_id: '2',
    image: 'https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=400',
    stock: 100
  },
  {
    id: '3',
    name_en: 'Coffee Maker',
    name_bn: 'কফি মেকার',
    description_en: 'Automatic coffee maker for home',
    description_bn: 'ঘরের জন্য স্বয়ংক্রিয় কফি মেকার',
    price: 5500,
    category_id: '3',
    image: 'https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=400',
    stock: 25
  }
];

// Storage keys
const CATEGORIES_KEY = 'ecommerce_categories';
const PRODUCTS_KEY = 'ecommerce_products';
const CART_KEY = 'ecommerce_cart';
const LANGUAGE_KEY = 'ecommerce_language';

// Initialize data
export const initializeData = () => {
  if (!localStorage.getItem(CATEGORIES_KEY)) {
    localStorage.setItem(CATEGORIES_KEY, JSON.stringify(defaultCategories));
  }
  if (!localStorage.getItem(PRODUCTS_KEY)) {
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(defaultProducts));
  }
  if (!localStorage.getItem(CART_KEY)) {
    localStorage.setItem(CART_KEY, JSON.stringify([]));
  }
  if (!localStorage.getItem(LANGUAGE_KEY)) {
    localStorage.setItem(LANGUAGE_KEY, 'en');
  }
};

// Categories
export const getCategories = (): Category[] => {
  const data = localStorage.getItem(CATEGORIES_KEY);
  return data ? JSON.parse(data) : [];
};

export const addCategory = (category: Omit<Category, 'id'>): void => {
  const categories = getCategories();
  const newCategory: Category = {
    ...category,
    id: Date.now().toString()
  };
  categories.push(newCategory);
  localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
};

export const deleteCategory = (id: string): void => {
  const categories = getCategories().filter(cat => cat.id !== id);
  localStorage.setItem(CATEGORIES_KEY, JSON.stringify(categories));
  
  // Also delete products in this category
  const products = getProducts().filter(prod => prod.category_id !== id);
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
};

// Products
export const getProducts = (): Product[] => {
  const data = localStorage.getItem(PRODUCTS_KEY);
  return data ? JSON.parse(data) : [];
};

export const addProduct = (product: Omit<Product, 'id'>): void => {
  const products = getProducts();
  const newProduct: Product = {
    ...product,
    id: Date.now().toString()
  };
  products.push(newProduct);
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
};

export const updateProduct = (id: string, updates: Partial<Product>): void => {
  const products = getProducts();
  const index = products.findIndex(p => p.id === id);
  if (index !== -1) {
    products[index] = { ...products[index], ...updates };
    localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
  }
};

export const deleteProduct = (id: string): void => {
  const products = getProducts().filter(prod => prod.id !== id);
  localStorage.setItem(PRODUCTS_KEY, JSON.stringify(products));
};

// Cart
export const getCart = (): CartItem[] => {
  const data = localStorage.getItem(CART_KEY);
  return data ? JSON.parse(data) : [];
};

export const addToCart = (productId: string, quantity: number = 1): void => {
  const cart = getCart();
  const existingItem = cart.find(item => item.product_id === productId);
  
  if (existingItem) {
    existingItem.quantity += quantity;
  } else {
    cart.push({ product_id: productId, quantity });
  }
  
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

export const removeFromCart = (productId: string): void => {
  const cart = getCart().filter(item => item.product_id !== productId);
  localStorage.setItem(CART_KEY, JSON.stringify(cart));
};

export const updateCartQuantity = (productId: string, quantity: number): void => {
  const cart = getCart();
  const item = cart.find(item => item.product_id === productId);
  if (item) {
    item.quantity = quantity;
    localStorage.setItem(CART_KEY, JSON.stringify(cart));
  }
};

export const clearCart = (): void => {
  localStorage.setItem(CART_KEY, JSON.stringify([]));
};

// Language
export const getLanguage = (): Language => {
  const lang = localStorage.getItem(LANGUAGE_KEY);
  return (lang as Language) || 'en';
};

export const setLanguage = (language: Language): void => {
  localStorage.setItem(LANGUAGE_KEY, language);
};

// Utility functions
export const formatPrice = (price: number): string => {
  return `৳${price.toLocaleString()}`;
};

export const getProductsByCategory = (categoryId: string): Product[] => {
  return getProducts().filter(product => product.category_id === categoryId);
};

export const searchProducts = (query: string, language: Language): Product[] => {
  const products = getProducts();
  const searchTerm = query.toLowerCase();
  
  return products.filter(product => {
    const name = language === 'en' ? product.name_en : product.name_bn;
    const description = language === 'en' ? product.description_en : product.description_bn;
    
    return name.toLowerCase().includes(searchTerm) || 
           description.toLowerCase().includes(searchTerm);
  });
};