# E-commerce Website MVP - "ALL In One Online Regular Store"

## Core Features to Implement:

### 1. Main Store Components (4 files)
- **src/pages/Index.tsx** - Main store homepage with product grid
- **src/components/ProductCard.tsx** - Individual product display component
- **src/components/Header.tsx** - Navigation with language switcher and cart
- **src/components/Cart.tsx** - Shopping cart sidebar

### 2. Admin Panel Components (3 files)
- **src/pages/Admin.tsx** - Admin dashboard with category/product management
- **src/components/AdminProductForm.tsx** - Form to add/edit products
- **src/components/AdminCategoryForm.tsx** - Form to add/edit categories

### 3. Core Logic (1 file)
- **src/lib/store.ts** - Data management with localStorage for products, categories, cart

## Data Structure:
- Categories: {id, name_en, name_bn}
- Products: {id, name_en, name_bn, price, category_id, image, description_en, description_bn}
- Cart: {product_id, quantity}
- Language: 'en' | 'bn'

## Key Features:
- Multi-language support (English/Bangla)
- Currency in Taka (৳)
- Admin can add categories and products
- Responsive design
- Local storage persistence

## Routes:
- / - Main store
- /admin - Admin panel