import { useState, useEffect } from 'react';
import { ShoppingCart, Search, Menu, User, Globe, ShoppingBag, Heart, Star } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getCart, getLanguage, setLanguage, type Language } from '@/lib/store';
import Cart from './Cart';

interface HeaderProps {
  onSearch: (query: string) => void;
  onCategoryFilter: (categoryId: string) => void;
}

const translations = {
  en: {
    storeName: 'ALL In One Online Regular Store',
    storeTagline: '🛍️ Your Ultimate Shopping Destination',
    search: 'Search for products, brands and more...',
    admin: 'Admin Panel',
    cart: 'Cart',
    language: 'Language'
  },
  bn: {
    storeName: 'অল ইন ওয়ান অনলাইন রেগুলার স্টোর',
    storeTagline: '🛍️ আপনার চূড়ান্ত কেনাকাটার গন্তব্য',
    search: 'পণ্য, ব্র্যান্ড এবং আরও অনেক কিছু খুঁজুন...',
    admin: 'অ্যাডমিন প্যানেল',
    cart: 'কার্ট',
    language: 'ভাষা'
  }
};

export default function Header({ onSearch, onCategoryFilter }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [cartItemCount, setCartItemCount] = useState(0);
  const [language, setCurrentLanguage] = useState<Language>(getLanguage());
  const [isCartOpen, setIsCartOpen] = useState(false);

  const t = translations[language];

  useEffect(() => {
    const updateCartCount = () => {
      const cart = getCart();
      const count = cart.reduce((total, item) => total + item.quantity, 0);
      setCartItemCount(count);
    };

    updateCartCount();
    
    // Listen for cart updates
    const handleStorageChange = () => updateCartCount();
    window.addEventListener('storage', handleStorageChange);
    
    // Custom event for same-tab updates
    window.addEventListener('cartUpdated', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('cartUpdated', handleStorageChange);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setCurrentLanguage(newLanguage);
    window.location.reload(); // Reload to update all components
  };

  const navigateToAdmin = () => {
    window.location.href = '/admin';
  };

  return (
    <header className="bg-white shadow-2xl border-b-4 border-gradient-to-r from-pink-400 via-purple-500 to-indigo-600 sticky top-0 z-50">
      {/* Top promotional banner */}
      <div className="bg-gradient-to-r from-pink-500 via-red-500 to-yellow-500 text-white text-center py-2 text-sm font-medium">
        🎉 Free Shipping on Orders Over ৳1000 | 24/7 Customer Support | 30-Day Returns 🎉
      </div>
      
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Enhanced E-commerce Logo */}
          <div className="flex items-center gap-4">
            <div className="relative group cursor-pointer">
              {/* Main Logo Container - Instagram/Facebook inspired */}
              <div className="relative w-20 h-20 bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600 rounded-3xl flex items-center justify-center shadow-2xl transform transition-all duration-500 group-hover:scale-110 group-hover:rotate-6 overflow-hidden">
                {/* Background Pattern */}
                <div className="absolute inset-0 bg-gradient-to-br from-white/20 to-transparent"></div>
                <div className="absolute top-2 right-2 w-3 h-3 bg-yellow-300 rounded-full animate-pulse"></div>
                <div className="absolute bottom-2 left-2 w-2 h-2 bg-pink-300 rounded-full animate-bounce"></div>
                
                {/* Central Shopping Icon */}
                <div className="relative z-10 flex flex-col items-center">
                  <ShoppingBag className="w-10 h-10 text-white mb-1" />
                  <div className="flex gap-1">
                    <div className="w-1 h-1 bg-yellow-300 rounded-full animate-ping"></div>
                    <div className="w-1 h-1 bg-pink-300 rounded-full animate-ping delay-100"></div>
                    <div className="w-1 h-1 bg-blue-300 rounded-full animate-ping delay-200"></div>
                  </div>
                </div>
                
                {/* Floating Elements */}
                <div className="absolute -top-2 -right-2 w-6 h-6 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full flex items-center justify-center animate-bounce">
                  <Heart className="w-3 h-3 text-white" />
                </div>
                <div className="absolute -bottom-2 -left-2 w-5 h-5 bg-gradient-to-r from-green-400 to-blue-500 rounded-full flex items-center justify-center animate-pulse">
                  <Star className="w-2 h-2 text-white" />
                </div>
              </div>
              
              {/* Outer Glow Ring */}
              <div className="absolute inset-0 w-20 h-20 bg-gradient-to-br from-pink-400 via-purple-500 to-indigo-600 rounded-3xl opacity-30 blur-xl animate-pulse scale-125"></div>
              
              {/* Rotating Border */}
              <div className="absolute inset-0 w-20 h-20 rounded-3xl border-4 border-transparent bg-gradient-to-r from-pink-400 via-purple-500 to-indigo-600 opacity-50 animate-spin-slow" style={{
                background: 'linear-gradient(45deg, transparent, transparent), linear-gradient(45deg, #ec4899, #8b5cf6, #4f46e5)',
                backgroundClip: 'padding-box, border-box',
                backgroundOrigin: 'padding-box, border-box'
              }}></div>
            </div>
            
            <div className="text-gray-800">
              <h1 className="text-2xl md:text-4xl font-black bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent hidden md:block leading-tight tracking-tight">
                ALL In One
              </h1>
              <h1 className="text-xl font-black bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent md:hidden">
                ALL In One
              </h1>
              <p className="text-sm font-semibold text-gray-600 hidden md:block flex items-center gap-1">
                {t.storeTagline}
              </p>
              <div className="hidden md:flex items-center gap-2 mt-1">
                <div className="flex">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-3 h-3 text-yellow-400 fill-current" />
                  ))}
                </div>
                <span className="text-xs text-gray-500 font-medium">4.9 (2.5k+ reviews)</span>
              </div>
            </div>
          </div>

          {/* Enhanced Search Bar - Amazon/eBay inspired */}
          <form onSubmit={handleSearch} className="flex-1 max-w-2xl mx-4">
            <div className="relative group">
              <div className="absolute inset-0 bg-gradient-to-r from-pink-400 via-purple-500 to-indigo-600 rounded-2xl opacity-20 blur-lg group-focus-within:opacity-40 transition-all duration-300"></div>
              <div className="relative flex">
                <div className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10">
                  <Search className="w-5 h-5 text-gray-400 group-focus-within:text-purple-500 transition-colors" />
                </div>
                <Input
                  type="text"
                  placeholder={t.search}
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-12 pr-20 py-4 bg-white border-2 border-gray-200 rounded-2xl shadow-lg focus:border-purple-400 focus:ring-4 focus:ring-purple-100 transition-all duration-300 text-base font-medium"
                />
                <Button
                  type="submit"
                  className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-gradient-to-r from-pink-500 to-purple-600 hover:from-pink-600 hover:to-purple-700 text-white px-6 py-2 rounded-xl shadow-lg transition-all duration-300"
                >
                  Search
                </Button>
              </div>
            </div>
          </form>

          {/* Enhanced Actions */}
          <div className="flex items-center gap-3">
            {/* Language Selector */}
            <div className="relative">
              <Select value={language} onValueChange={handleLanguageChange}>
                <SelectTrigger className="w-32 bg-gradient-to-r from-blue-50 to-purple-50 border-2 border-blue-200 hover:border-purple-300 text-gray-700 font-medium transition-all duration-300">
                  <Globe className="w-4 h-4 mr-2 text-purple-500" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="en">🇺🇸 English</SelectItem>
                  <SelectItem value="bn">🇧🇩 বাংলা</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Admin Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={navigateToAdmin}
              className="hidden md:flex items-center gap-2 bg-gradient-to-r from-gray-50 to-gray-100 border-2 border-gray-200 hover:border-purple-300 text-gray-700 hover:text-purple-600 font-medium transition-all duration-300"
            >
              <User className="w-4 h-4" />
              {t.admin}
            </Button>

            {/* Enhanced Cart - Shopify/WooCommerce inspired */}
            <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
              <SheetTrigger asChild>
                <Button 
                  size="lg"
                  className="relative bg-gradient-to-r from-orange-400 via-pink-500 to-red-500 hover:from-orange-500 hover:via-pink-600 hover:to-red-600 text-white shadow-2xl transform transition-all duration-300 hover:scale-105 px-6 py-3 rounded-2xl font-bold"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span className="hidden md:inline ml-2">{t.cart}</span>
                  {cartItemCount > 0 && (
                    <>
                      <Badge 
                        variant="destructive" 
                        className="absolute -top-3 -right-3 w-7 h-7 rounded-full p-0 flex items-center justify-center text-xs font-bold bg-yellow-400 text-black animate-bounce border-2 border-white"
                      >
                        {cartItemCount}
                      </Badge>
                      <div className="absolute -top-1 -right-1 w-4 h-4 bg-yellow-300 rounded-full animate-ping"></div>
                    </>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <Cart onClose={() => setIsCartOpen(false)} />
              </SheetContent>
            </Sheet>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="md:hidden border-2 border-purple-200 hover:border-purple-400 text-purple-600"
                >
                  <Menu className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-4 mt-8">
                  <Button
                    variant="outline"
                    onClick={navigateToAdmin}
                    className="flex items-center gap-2 justify-start"
                  >
                    <User className="w-4 h-4" />
                    {t.admin}
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
      
      {/* Decorative Bottom Border with Animation */}
      <div className="h-2 bg-gradient-to-r from-pink-400 via-purple-500 to-indigo-600 relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-shimmer"></div>
      </div>
    </header>
  );
}