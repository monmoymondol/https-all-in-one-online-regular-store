import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Package, Tag, ArrowLeft, Home } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from '@/components/ui/alert-dialog';
import { toast } from 'sonner';
import AdminProductForm from '@/components/AdminProductForm';
import AdminCategoryForm from '@/components/AdminCategoryForm';
import { 
  getProducts, 
  getCategories, 
  deleteProduct, 
  deleteCategory,
  formatPrice,
  getLanguage,
  type Product, 
  type Category,
  type Language 
} from '@/lib/store';

const translations = {
  en: {
    adminPanel: 'Admin Panel',
    dashboard: 'Dashboard',
    products: 'Products',
    categories: 'Categories',
    backToStore: 'Back to Store',
    totalProducts: 'Total Products',
    totalCategories: 'Total Categories',
    addProduct: 'Add Product',
    addCategory: 'Add Category',
    edit: 'Edit',
    delete: 'Delete',
    confirmDelete: 'Are you sure?',
    deleteProductDesc: 'This will permanently delete this product. This action cannot be undone.',
    deleteCategoryDesc: 'This will permanently delete this category and all its products. This action cannot be undone.',
    cancel: 'Cancel',
    deleteConfirm: 'Delete',
    productDeleted: 'Product deleted successfully',
    categoryDeleted: 'Category deleted successfully',
    noProducts: 'No products found',
    noCategories: 'No categories found',
    stock: 'Stock',
    outOfStock: 'Out of Stock'
  },
  bn: {
    adminPanel: 'অ্যাডমিন প্যানেল',
    dashboard: 'ড্যাশবোর্ড',
    products: 'পণ্য',
    categories: 'ক্যাটাগরি',
    backToStore: 'স্টোরে ফিরে যান',
    totalProducts: 'মোট পণ্য',
    totalCategories: 'মোট ক্যাটাগরি',
    addProduct: 'পণ্য যোগ করুন',
    addCategory: 'ক্যাটাগরি যোগ করুন',
    edit: 'সম্পাদনা',
    delete: 'মুছুন',
    confirmDelete: 'আপনি কি নিশ্চিত?',
    deleteProductDesc: 'এটি স্থায়ীভাবে এই পণ্যটি মুছে দেবে। এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।',
    deleteCategoryDesc: 'এটি স্থায়ীভাবে এই ক্যাটাগরি এবং এর সমস্ত পণ্য মুছে দেবে। এই কাজটি পূর্বাবস্থায় ফেরানো যাবে না।',
    cancel: 'বাতিল',
    deleteConfirm: 'মুছুন',
    productDeleted: 'পণ্য সফলভাবে মুছে ফেলা হয়েছে',
    categoryDeleted: 'ক্যাটাগরি সফলভাবে মুছে ফেলা হয়েছে',
    noProducts: 'কোন পণ্য পাওয়া যায়নি',
    noCategories: 'কোন ক্যাটাগরি পাওয়া যায়নি',
    stock: 'স্টক',
    outOfStock: 'স্টক নেই'
  }
};

export default function Admin() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [showProductForm, setShowProductForm] = useState(false);
  const [showCategoryForm, setShowCategoryForm] = useState(false);
  const [editingProduct, setEditingProduct] = useState<Product | undefined>();
  const [editingCategory, setEditingCategory] = useState<Category | undefined>();
  const [activeTab, setActiveTab] = useState('dashboard');
  const language: Language = getLanguage();
  const t = translations[language];

  useEffect(() => {
    loadData();
  }, []);

  const loadData = () => {
    setProducts(getProducts());
    setCategories(getCategories());
  };

  const handleDeleteProduct = async (productId: string) => {
    try {
      deleteProduct(productId);
      loadData();
      toast.success(t.productDeleted);
    } catch (error) {
      toast.error('Error deleting product');
    }
  };

  const handleDeleteCategory = async (categoryId: string) => {
    try {
      deleteCategory(categoryId);
      loadData();
      toast.success(t.categoryDeleted);
    } catch (error) {
      toast.error('Error deleting category');
    }
  };

  const handleProductSave = () => {
    setShowProductForm(false);
    setEditingProduct(undefined);
    loadData();
  };

  const handleCategorySave = () => {
    setShowCategoryForm(false);
    setEditingCategory(undefined);
    loadData();
  };

  const getCategoryName = (categoryId: string): string => {
    const category = categories.find(cat => cat.id === categoryId);
    if (!category) return 'Unknown';
    return language === 'en' ? category.name_en : category.name_bn;
  };

  const navigateToStore = () => {
    window.location.href = '/';
  };

  if (showProductForm) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <AdminProductForm
            product={editingProduct}
            onSave={handleProductSave}
            onCancel={() => {
              setShowProductForm(false);
              setEditingProduct(undefined);
            }}
          />
        </div>
      </div>
    );
  }

  if (showCategoryForm) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="container mx-auto px-4">
          <AdminCategoryForm
            category={editingCategory}
            onSave={handleCategorySave}
            onCancel={() => {
              setShowCategoryForm(false);
              setEditingCategory(undefined);
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-2">
                <div className="w-8 h-8 bg-red-600 rounded-lg flex items-center justify-center">
                  <span className="text-white font-bold text-sm">A</span>
                </div>
                <h1 className="text-2xl font-bold text-gray-900">{t.adminPanel}</h1>
              </div>
            </div>
            
            <Button onClick={navigateToStore} variant="outline">
              <ArrowLeft className="w-4 h-4 mr-2" />
              {t.backToStore}
            </Button>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-3">
            <TabsTrigger value="dashboard">{t.dashboard}</TabsTrigger>
            <TabsTrigger value="products">{t.products}</TabsTrigger>
            <TabsTrigger value="categories">{t.categories}</TabsTrigger>
          </TabsList>

          {/* Dashboard Tab */}
          <TabsContent value="dashboard" className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t.totalProducts}</CardTitle>
                  <Package className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{products.length}</div>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">{t.totalCategories}</CardTitle>
                  <Tag className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{categories.length}</div>
                </CardContent>
              </Card>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Card>
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent className="space-y-4">
                  <Button 
                    onClick={() => setShowProductForm(true)}
                    className="w-full justify-start"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {t.addProduct}
                  </Button>
                  <Button 
                    onClick={() => setShowCategoryForm(true)}
                    variant="outline"
                    className="w-full justify-start"
                  >
                    <Plus className="w-4 h-4 mr-2" />
                    {t.addCategory}
                  </Button>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Products Tab */}
          <TabsContent value="products" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">{t.products}</h2>
              <Button onClick={() => setShowProductForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                {t.addProduct}
              </Button>
            </div>

            {products.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Package className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">{t.noProducts}</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {products.map((product) => (
                  <Card key={product.id}>
                    <CardContent className="p-4">
                      <div className="flex gap-3">
                        <img
                          src={product.image}
                          alt={language === 'en' ? product.name_en : product.name_bn}
                          className="w-16 h-16 object-cover rounded-md"
                          onError={(e) => {
                            const target = e.target as HTMLImageElement;
                            target.src = 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=100&fit=crop';
                          }}
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-semibold text-sm line-clamp-2 mb-1">
                            {language === 'en' ? product.name_en : product.name_bn}
                          </h3>
                          <p className="text-blue-600 font-semibold text-sm mb-2">
                            {formatPrice(product.price)}
                          </p>
                          <div className="flex items-center gap-2 mb-3">
                            <Badge variant="secondary" className="text-xs">
                              {getCategoryName(product.category_id)}
                            </Badge>
                            <Badge 
                              variant={product.stock > 0 ? "default" : "destructive"}
                              className="text-xs"
                            >
                              {product.stock > 0 ? `${product.stock} ${t.stock}` : t.outOfStock}
                            </Badge>
                          </div>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              onClick={() => {
                                setEditingProduct(product);
                                setShowProductForm(true);
                              }}
                            >
                              <Edit className="w-3 h-3" />
                            </Button>
                            <AlertDialog>
                              <AlertDialogTrigger asChild>
                                <Button size="sm" variant="outline">
                                  <Trash2 className="w-3 h-3" />
                                </Button>
                              </AlertDialogTrigger>
                              <AlertDialogContent>
                                <AlertDialogHeader>
                                  <AlertDialogTitle>{t.confirmDelete}</AlertDialogTitle>
                                  <AlertDialogDescription>
                                    {t.deleteProductDesc}
                                  </AlertDialogDescription>
                                </AlertDialogHeader>
                                <AlertDialogFooter>
                                  <AlertDialogCancel>{t.cancel}</AlertDialogCancel>
                                  <AlertDialogAction
                                    onClick={() => handleDeleteProduct(product.id)}
                                    className="bg-red-600 hover:bg-red-700"
                                  >
                                    {t.deleteConfirm}
                                  </AlertDialogAction>
                                </AlertDialogFooter>
                              </AlertDialogContent>
                            </AlertDialog>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>

          {/* Categories Tab */}
          <TabsContent value="categories" className="space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-2xl font-bold">{t.categories}</h2>
              <Button onClick={() => setShowCategoryForm(true)}>
                <Plus className="w-4 h-4 mr-2" />
                {t.addCategory}
              </Button>
            </div>

            {categories.length === 0 ? (
              <Card>
                <CardContent className="text-center py-8">
                  <Tag className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <p className="text-gray-600">{t.noCategories}</p>
                </CardContent>
              </Card>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {categories.map((category) => (
                  <Card key={category.id}>
                    <CardContent className="p-4">
                      <div className="flex items-center justify-between">
                        <div>
                          <h3 className="font-semibold mb-1">
                            {language === 'en' ? category.name_en : category.name_bn}
                          </h3>
                          <p className="text-sm text-gray-600">
                            {getProducts().filter(p => p.category_id === category.id).length} products
                          </p>
                        </div>
                        <div className="flex gap-2">
                          <Button
                            size="sm"
                            variant="outline"
                            onClick={() => {
                              setEditingCategory(category);
                              setShowCategoryForm(true);
                            }}
                          >
                            <Edit className="w-3 h-3" />
                          </Button>
                          <AlertDialog>
                            <AlertDialogTrigger asChild>
                              <Button size="sm" variant="outline">
                                <Trash2 className="w-3 h-3" />
                              </Button>
                            </AlertDialogTrigger>
                            <AlertDialogContent>
                              <AlertDialogHeader>
                                <AlertDialogTitle>{t.confirmDelete}</AlertDialogTitle>
                                <AlertDialogDescription>
                                  {t.deleteCategoryDesc}
                                </AlertDialogDescription>
                              </AlertDialogHeader>
                              <AlertDialogFooter>
                                <AlertDialogCancel>{t.cancel}</AlertDialogCancel>
                                <AlertDialogAction
                                  onClick={() => handleDeleteCategory(category.id)}
                                  className="bg-red-600 hover:bg-red-700"
                                >
                                  {t.deleteConfirm}
                                </AlertDialogAction>
                              </AlertDialogFooter>
                            </AlertDialogContent>
                          </AlertDialog>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}