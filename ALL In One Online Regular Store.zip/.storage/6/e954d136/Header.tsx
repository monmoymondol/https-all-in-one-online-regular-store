import { useState, useEffect } from 'react';
import { ShoppingCart, Search, Menu, User, Globe } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { getCart, getLanguage, setLanguage, type Language } from '@/lib/store';
import Cart from './Cart';

interface HeaderProps {
  onSearch: (query: string) => void;
  onCategoryFilter: (categoryId: string) => void;
}

const translations = {
  en: {
    storeName: 'ALL In One Online Regular Store',
    search: 'Search products...',
    admin: 'Admin Panel',
    cart: 'Cart',
    language: 'Language'
  },
  bn: {
    storeName: 'অল ইন ওয়ান অনলাইন রেগুলার স্টোর',
    search: 'পণ্য খুঁজুন...',
    admin: 'অ্যাডমিন প্যানেল',
    cart: 'কার্ট',
    language: 'ভাষা'
  }
};

export default function Header({ onSearch, onCategoryFilter }: HeaderProps) {
  const [searchQuery, setSearchQuery] = useState('');
  const [cartItemCount, setCartItemCount] = useState(0);
  const [language, setCurrentLanguage] = useState<Language>(getLanguage());
  const [isCartOpen, setIsCartOpen] = useState(false);

  const t = translations[language];

  useEffect(() => {
    const updateCartCount = () => {
      const cart = getCart();
      const count = cart.reduce((total, item) => total + item.quantity, 0);
      setCartItemCount(count);
    };

    updateCartCount();
    
    // Listen for cart updates
    const handleStorageChange = () => updateCartCount();
    window.addEventListener('storage', handleStorageChange);
    
    // Custom event for same-tab updates
    window.addEventListener('cartUpdated', handleStorageChange);
    
    return () => {
      window.removeEventListener('storage', handleStorageChange);
      window.removeEventListener('cartUpdated', handleStorageChange);
    };
  }, []);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    onSearch(searchQuery);
  };

  const handleLanguageChange = (newLanguage: Language) => {
    setLanguage(newLanguage);
    setCurrentLanguage(newLanguage);
    window.location.reload(); // Reload to update all components
  };

  const navigateToAdmin = () => {
    window.location.href = '/admin';
  };

  return (
    <header className="bg-white shadow-md border-b">
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between gap-4">
          {/* Logo */}
          <div className="flex items-center gap-2">
            <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold text-sm">AO</span>
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900 hidden md:block">
                {t.storeName}
              </h1>
              <h1 className="text-lg font-bold text-gray-900 md:hidden">
                ALL In One
              </h1>
            </div>
          </div>

          {/* Search Bar */}
          <form onSubmit={handleSearch} className="flex-1 max-w-md mx-4">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
              <Input
                type="text"
                placeholder={t.search}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 pr-4"
              />
            </div>
          </form>

          {/* Actions */}
          <div className="flex items-center gap-2">
            {/* Language Selector */}
            <Select value={language} onValueChange={handleLanguageChange}>
              <SelectTrigger className="w-24">
                <Globe className="w-4 h-4 mr-1" />
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="en">EN</SelectItem>
                <SelectItem value="bn">বাং</SelectItem>
              </SelectContent>
            </Select>

            {/* Admin Button */}
            <Button
              variant="outline"
              size="sm"
              onClick={navigateToAdmin}
              className="hidden md:flex items-center gap-2"
            >
              <User className="w-4 h-4" />
              {t.admin}
            </Button>

            {/* Cart */}
            <Sheet open={isCartOpen} onOpenChange={setIsCartOpen}>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="relative">
                  <ShoppingCart className="w-4 h-4" />
                  <span className="hidden md:inline ml-2">{t.cart}</span>
                  {cartItemCount > 0 && (
                    <Badge 
                      variant="destructive" 
                      className="absolute -top-2 -right-2 w-5 h-5 rounded-full p-0 flex items-center justify-center text-xs"
                    >
                      {cartItemCount}
                    </Badge>
                  )}
                </Button>
              </SheetTrigger>
              <SheetContent>
                <Cart onClose={() => setIsCartOpen(false)} />
              </SheetContent>
            </Sheet>

            {/* Mobile Menu */}
            <Sheet>
              <SheetTrigger asChild>
                <Button variant="outline" size="sm" className="md:hidden">
                  <Menu className="w-4 h-4" />
                </Button>
              </SheetTrigger>
              <SheetContent>
                <div className="flex flex-col gap-4 mt-8">
                  <Button
                    variant="outline"
                    onClick={navigateToAdmin}
                    className="flex items-center gap-2 justify-start"
                  >
                    <User className="w-4 h-4" />
                    {t.admin}
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </div>
    </header>
  );
}