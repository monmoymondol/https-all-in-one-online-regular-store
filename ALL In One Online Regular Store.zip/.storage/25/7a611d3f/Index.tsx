import { useState, useEffect } from 'react';
import { Filter, Grid, List, Sparkles, TrendingUp, Star, Heart, ShoppingBag, Zap, Gift } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';
import { 
  initializeData, 
  getProducts, 
  getCategories, 
  searchProducts,
  getProductsByCategory,
  getLanguage,
  type Product, 
  type Category,
  type Language 
} from '@/lib/store';

const translations = {
  en: {
    allCategories: 'All Categories',
    noProducts: 'No products found',
    noProductsDesc: 'Try adjusting your search or filter criteria',
    products: 'Products',
    showing: 'Showing',
    of: 'of',
    featuredProducts: '🔥 Hot Deals',
    trendingNow: 'Trending Products',
    clearFilters: 'Clear All Filters',
    shopNow: 'Shop Now',
    limitedTime: 'Limited Time Offer',
    freeShipping: 'Free Shipping',
    bestSeller: 'Best Seller',
    filterProducts: 'Filter Products'
  },
  bn: {
    allCategories: 'সব ক্যাটাগরি',
    noProducts: 'কোন পণ্য পাওয়া যায়নি',
    noProductsDesc: 'আপনার অনুসন্ধান বা ফিল্টার মানদণ্ড সামঞ্জস্য করার চেষ্টা করুন',
    products: 'পণ্য',
    showing: 'দেখানো হচ্ছে',
    of: 'এর মধ্যে',
    featuredProducts: '🔥 হট ডিল',
    trendingNow: 'ট্রেন্ডিং পণ্য',
    clearFilters: 'সব ফিল্টার পরিষ্কার করুন',
    shopNow: 'এখনই কিনুন',
    limitedTime: 'সীমিত সময়ের অফার',
    freeShipping: 'ফ্রি শিপিং',
    bestSeller: 'বেস্ট সেলার',
    filterProducts: 'পণ্য ফিল্টার করুন'
  }
};

export default function Index() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isLoading, setIsLoading] = useState(true);
  const language: Language = getLanguage();
  const t = translations[language];

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterProducts();
  }, [products, selectedCategory, searchQuery]);

  const loadData = async () => {
    try {
      initializeData();
      const productsData = getProducts();
      const categoriesData = getCategories();
      
      setProducts(productsData);
      setCategories(categoriesData);
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setIsLoading(false);
    }
  };

  const filterProducts = () => {
    let filtered = products;

    // Apply search filter
    if (searchQuery.trim()) {
      filtered = searchProducts(searchQuery, language);
    }

    // Apply category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(product => product.category_id === selectedCategory);
    }

    setFilteredProducts(filtered);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleCategoryFilter = (categoryId: string) => {
    setSelectedCategory(categoryId);
  };

  const getCategoryName = (categoryId: string): string => {
    const category = categories.find(cat => cat.id === categoryId);
    if (!category) return '';
    return language === 'en' ? category.name_en : category.name_bn;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50">
        <Header onSearch={handleSearch} onCategoryFilter={handleCategoryFilter} />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="flex flex-col items-center gap-4">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-pink-500 border-t-transparent rounded-full animate-spin"></div>
                <div className="absolute inset-0 w-16 h-16 border-4 border-purple-300 border-b-transparent rounded-full animate-spin animate-reverse"></div>
              </div>
              <div className="text-center">
                <h3 className="text-2xl font-bold bg-gradient-to-r from-pink-600 to-purple-600 bg-clip-text text-transparent">
                  Loading Amazing Products...
                </h3>
                <p className="text-gray-600 mt-2">Get ready for the best shopping experience!</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-50 via-purple-50 to-indigo-50">
      <Header onSearch={handleSearch} onCategoryFilter={handleCategoryFilter} />
      
      <main className="container mx-auto px-4 py-8">
        {/* Enhanced Hero Section */}
        <div className="mb-12 text-center relative overflow-hidden">
          {/* Background Decorations */}
          <div className="absolute inset-0 overflow-hidden">
            <div className="absolute top-10 left-10 w-20 h-20 bg-pink-200 rounded-full opacity-50 animate-float"></div>
            <div className="absolute top-20 right-20 w-16 h-16 bg-purple-200 rounded-full opacity-50 animate-float delay-1000"></div>
            <div className="absolute bottom-10 left-1/4 w-12 h-12 bg-indigo-200 rounded-full opacity-50 animate-float delay-2000"></div>
          </div>
          
          <div className="relative z-10">
            <div className="inline-flex items-center gap-3 bg-gradient-to-r from-pink-500 via-red-500 to-orange-500 text-white px-8 py-3 rounded-full text-lg font-bold mb-6 shadow-2xl animate-glow">
              <Zap className="w-6 h-6 animate-bounce" />
              {t.featuredProducts}
              <Sparkles className="w-6 h-6 animate-pulse" />
            </div>
            
            <h2 className="text-5xl md:text-7xl font-black bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-6 leading-tight">
              {t.trendingNow}
            </h2>
            
            <p className="text-xl text-gray-700 max-w-3xl mx-auto mb-8 font-medium">
              🌟 Discover amazing products at unbeatable prices with lightning-fast delivery 🚀
            </p>
            
            {/* Promotional Badges */}
            <div className="flex flex-wrap justify-center gap-4 mb-8">
              <Badge className="bg-gradient-to-r from-green-400 to-blue-500 text-white px-6 py-2 text-sm font-bold rounded-full">
                <Gift className="w-4 h-4 mr-2" />
                {t.freeShipping}
              </Badge>
              <Badge className="bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-6 py-2 text-sm font-bold rounded-full animate-pulse">
                <Star className="w-4 h-4 mr-2" />
                {t.bestSeller}
              </Badge>
              <Badge className="bg-gradient-to-r from-red-400 to-pink-500 text-white px-6 py-2 text-sm font-bold rounded-full">
                <Heart className="w-4 h-4 mr-2" />
                {t.limitedTime}
              </Badge>
            </div>
          </div>
        </div>

        {/* Ultra Enhanced Filters */}
        <div className="bg-white/80 backdrop-blur-xl rounded-3xl shadow-2xl border-2 border-white/50 p-8 mb-12 relative overflow-hidden">
          {/* Background Pattern */}
          <div className="absolute inset-0 bg-gradient-to-r from-pink-100/50 via-purple-100/50 to-indigo-100/50"></div>
          
          <div className="relative z-10 flex flex-col md:flex-row gap-6">
            <div className="flex items-center gap-6 flex-1">
              <div className="flex items-center gap-3">
                <div className="w-14 h-14 bg-gradient-to-br from-pink-500 via-purple-500 to-indigo-500 rounded-2xl flex items-center justify-center shadow-xl">
                  <Filter className="w-7 h-7 text-white" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold text-gray-800">{t.filterProducts}</h3>
                  <p className="text-gray-600">Find exactly what you're looking for</p>
                </div>
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-72 bg-white/90 border-3 border-purple-200 hover:border-purple-400 transition-all duration-300 text-lg font-medium py-4">
                  <SelectValue placeholder={t.allCategories} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t.allCategories}</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {language === 'en' ? category.name_en : category.name_bn}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-3">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="lg"
                onClick={() => setViewMode('grid')}
                className="transition-all duration-300 px-6 py-3"
              >
                <Grid className="w-5 h-5" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="lg"
                onClick={() => setViewMode('list')}
                className="transition-all duration-300 px-6 py-3"
              >
                <List className="w-5 h-5" />
              </Button>
            </div>
          </div>
        </div>

        {/* Enhanced Results Info */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-3">
              <TrendingUp className="w-8 h-8 text-purple-600" />
              <h3 className="text-4xl font-black text-gray-900">{t.products}</h3>
            </div>
            <Badge 
              variant="secondary" 
              className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 text-white px-6 py-3 text-lg font-bold rounded-full shadow-lg"
            >
              {t.showing} {filteredProducts.length} {t.of} {products.length}
            </Badge>
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-40 h-40 mx-auto mb-8 bg-gradient-to-br from-pink-100 via-purple-100 to-indigo-100 rounded-full flex items-center justify-center shadow-2xl">
              <ShoppingBag className="w-16 h-16 text-gray-400" />
            </div>
            <h3 className="text-3xl font-bold text-gray-900 mb-4">{t.noProducts}</h3>
            <p className="text-xl text-gray-600 mb-10 max-w-md mx-auto">{t.noProductsDesc}</p>
            <Button 
              variant="default"
              size="lg"
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="bg-gradient-to-r from-pink-500 via-purple-500 to-indigo-500 hover:from-pink-600 hover:via-purple-600 hover:to-indigo-600 text-white px-12 py-4 rounded-2xl shadow-2xl transform transition-all duration-300 hover:scale-105 text-lg font-bold"
            >
              <Sparkles className="w-6 h-6 mr-3" />
              {t.clearFilters}
            </Button>
          </div>
        ) : (
          <div className={
            viewMode === 'grid' 
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8'
              : 'grid grid-cols-1 md:grid-cols-2 gap-8'
          }>
            {filteredProducts.map((product, index) => (
              <div 
                key={product.id}
                className="transform transition-all duration-500 hover:scale-105"
                style={{
                  animationDelay: `${index * 100}ms`
                }}
              >
                <ProductCard
                  product={product}
                  categoryName={getCategoryName(product.category_id)}
                />
              </div>
            ))}
          </div>
        )}
      </main>
      
      {/* Enhanced Decorative Footer */}
      <footer className="mt-20 bg-gradient-to-r from-pink-600 via-purple-600 to-indigo-700 text-white py-12 relative overflow-hidden">
        {/* Background Pattern */}
        <div className="absolute inset-0">
          <div className="absolute top-10 left-10 w-32 h-32 bg-white/10 rounded-full animate-float"></div>
          <div className="absolute bottom-10 right-10 w-24 h-24 bg-white/10 rounded-full animate-float delay-1000"></div>
          <div className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 w-40 h-40 bg-white/5 rounded-full animate-pulse"></div>
        </div>
        
        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="flex items-center justify-center gap-3 mb-6">
            <Heart className="w-8 h-8 text-pink-300 animate-pulse" />
            <p className="text-2xl font-bold">
              Thank you for shopping with {t.storeName}
            </p>
            <Heart className="w-8 h-8 text-pink-300 animate-pulse" />
          </div>
          
          <p className="text-lg opacity-90 mb-6">
            🌟 Your satisfaction is our priority • 24/7 Support • Fast Delivery 🚀
          </p>
          
          <div className="flex justify-center mb-6">
            <div className="w-24 h-2 bg-gradient-to-r from-yellow-400 via-orange-500 to-red-500 rounded-full animate-shimmer"></div>
          </div>
          
          <div className="flex justify-center gap-6">
            {[...Array(5)].map((_, i) => (
              <Star key={i} className="w-6 h-6 text-yellow-300 fill-current animate-pulse" style={{
                animationDelay: `${i * 200}ms`
              }} />
            ))}
          </div>
        </div>
      </footer>
    </div>
  );
}