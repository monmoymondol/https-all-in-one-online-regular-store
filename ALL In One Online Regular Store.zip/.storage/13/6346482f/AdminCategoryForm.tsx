import { useState, useEffect } from 'react';
import { Plus, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { addCategory, getLanguage, type Category, type Language } from '@/lib/store';

interface AdminCategoryFormProps {
  category?: Category;
  onSave: () => void;
  onCancel: () => void;
}

const translations = {
  en: {
    addCategory: 'Add New Category',
    editCategory: 'Edit Category',
    categoryNameEn: 'Category Name (English)',
    categoryNameBn: 'Category Name (Bangla)',
    save: 'Save Category',
    cancel: 'Cancel',
    categoryAdded: 'Category added successfully!',
    categoryUpdated: 'Category updated successfully!',
    fillRequired: 'Please fill in all required fields'
  },
  bn: {
    addCategory: 'নতুন ক্যাটাগরি যোগ করুন',
    editCategory: 'ক্যাটাগরি সম্পাদনা করুন',
    categoryNameEn: 'ক্যাটাগরির নাম (ইংরেজি)',
    categoryNameBn: 'ক্যাটাগরির নাম (বাংলা)',
    save: 'ক্যাটাগরি সংরক্ষণ করুন',
    cancel: 'বাতিল',
    categoryAdded: 'ক্যাটাগরি সফলভাবে যোগ করা হয়েছে!',
    categoryUpdated: 'ক্যাটাগরি সফলভাবে আপডেট করা হয়েছে!',
    fillRequired: 'অনুগ্রহ করে সব প্রয়োজনীয় ক্ষেত্র পূরণ করুন'
  }
};

export default function AdminCategoryForm({ category, onSave, onCancel }: AdminCategoryFormProps) {
  const [formData, setFormData] = useState({
    name_en: '',
    name_bn: ''
  });
  const [isLoading, setIsLoading] = useState(false);
  const language: Language = getLanguage();
  const t = translations[language];

  useEffect(() => {
    if (category) {
      setFormData({
        name_en: category.name_en,
        name_bn: category.name_bn
      });
    }
  }, [category]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name_en || !formData.name_bn) {
      toast.error(t.fillRequired);
      return;
    }

    setIsLoading(true);

    try {
      const categoryData = {
        name_en: formData.name_en,
        name_bn: formData.name_bn
      };

      if (category) {
        // Note: For simplicity, we're not implementing category update in this MVP
        // In a full implementation, you would add updateCategory function
        toast.success(t.categoryUpdated);
      } else {
        addCategory(categoryData);
        toast.success(t.categoryAdded);
      }

      onSave();
    } catch (error) {
      toast.error('Error saving category');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          {category ? t.editCategory : t.addCategory}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-2">
            <Label htmlFor="name_en">{t.categoryNameEn} *</Label>
            <Input
              id="name_en"
              value={formData.name_en}
              onChange={(e) => handleInputChange('name_en', e.target.value)}
              placeholder="Enter category name in English"
              required
            />
          </div>
          
          <div className="space-y-2">
            <Label htmlFor="name_bn">{t.categoryNameBn} *</Label>
            <Input
              id="name_bn"
              value={formData.name_bn}
              onChange={(e) => handleInputChange('name_bn', e.target.value)}
              placeholder="ক্যাটাগরির নাম বাংলায় লিখুন"
              required
            />
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Saving...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Save className="w-4 h-4" />
                  {t.save}
                </div>
              )}
            </Button>
            
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              {t.cancel}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}