import { useState, useEffect } from 'react';
import { Minus, Plus, Trash2, ShoppingBag } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Separator } from '@/components/ui/separator';
import { ScrollArea } from '@/components/ui/scroll-area';
import { toast } from 'sonner';
import { 
  getCart, 
  getProducts, 
  removeFromCart, 
  updateCartQuantity, 
  clearCart,
  formatPrice,
  getLanguage,
  type Language,
  type CartItem,
  type Product 
} from '@/lib/store';

interface CartProps {
  onClose: () => void;
}

const translations = {
  en: {
    cart: 'Shopping Cart',
    empty: 'Your cart is empty',
    startShopping: 'Start Shopping',
    total: 'Total',
    checkout: 'Checkout',
    remove: 'Remove',
    cleared: 'Cart cleared!',
    orderPlaced: 'Order placed successfully!',
    items: 'items'
  },
  bn: {
    cart: 'শপিং কার্ট',
    empty: 'আপনার কার্ট খালি',
    startShopping: 'কেনাকাটা শুরু করুন',
    total: 'মোট',
    checkout: 'চেকআউট',
    remove: 'সরান',
    cleared: 'কার্ট পরিষ্কার করা হয়েছে!',
    orderPlaced: 'অর্ডার সফলভাবে দেওয়া হয়েছে!',
    items: 'আইটেম'
  }
};

export default function Cart({ onClose }: CartProps) {
  const [cartItems, setCartItems] = useState<CartItem[]>([]);
  const [products, setProducts] = useState<Product[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const language: Language = getLanguage();
  const t = translations[language];

  useEffect(() => {
    loadCartData();
  }, []);

  const loadCartData = () => {
    const cart = getCart();
    const allProducts = getProducts();
    setCartItems(cart);
    setProducts(allProducts);
  };

  const getProductById = (productId: string): Product | undefined => {
    return products.find(p => p.id === productId);
  };

  const updateQuantity = (productId: string, newQuantity: number) => {
    if (newQuantity <= 0) {
      handleRemoveItem(productId);
      return;
    }

    updateCartQuantity(productId, newQuantity);
    loadCartData();
    window.dispatchEvent(new CustomEvent('cartUpdated'));
  };

  const handleRemoveItem = (productId: string) => {
    removeFromCart(productId);
    loadCartData();
    window.dispatchEvent(new CustomEvent('cartUpdated'));
    toast.success(t.remove);
  };

  const calculateTotal = (): number => {
    return cartItems.reduce((total, item) => {
      const product = getProductById(item.product_id);
      return product ? total + (product.price * item.quantity) : total;
    }, 0);
  };

  const getTotalItems = (): number => {
    return cartItems.reduce((total, item) => total + item.quantity, 0);
  };

  const handleCheckout = async () => {
    if (cartItems.length === 0) return;

    setIsLoading(true);
    
    try {
      // Simulate checkout process
      await new Promise(resolve => setTimeout(resolve, 2000));
      
      clearCart();
      loadCartData();
      window.dispatchEvent(new CustomEvent('cartUpdated'));
      
      toast.success(t.orderPlaced);
      onClose();
    } catch (error) {
      toast.error('Checkout failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="h-full flex flex-col">
        <div className="flex items-center gap-2 mb-6">
          <ShoppingBag className="w-5 h-5" />
          <h2 className="text-lg font-semibold">{t.cart}</h2>
        </div>
        
        <div className="flex-1 flex flex-col items-center justify-center text-center">
          <ShoppingBag className="w-16 h-16 text-gray-300 mb-4" />
          <p className="text-gray-500 mb-4">{t.empty}</p>
          <Button onClick={onClose} variant="outline">
            {t.startShopping}
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-2">
          <ShoppingBag className="w-5 h-5" />
          <h2 className="text-lg font-semibold">{t.cart}</h2>
        </div>
        <Badge variant="secondary">
          {getTotalItems()} {t.items}
        </Badge>
      </div>

      <ScrollArea className="flex-1 -mx-6 px-6">
        <div className="space-y-4">
          {cartItems.map((item) => {
            const product = getProductById(item.product_id);
            if (!product) return null;

            const productName = language === 'en' ? product.name_en : product.name_bn;

            return (
              <div key={item.product_id} className="flex gap-3 p-3 border rounded-lg">
                <img
                  src={product.image}
                  alt={productName}
                  className="w-16 h-16 object-cover rounded-md"
                  onError={(e) => {
                    const target = e.target as HTMLImageElement;
                    target.src = 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=100&h=100&fit=crop';
                  }}
                />
                
                <div className="flex-1 min-w-0">
                  <h3 className="font-medium text-sm line-clamp-2 mb-1">
                    {productName}
                  </h3>
                  <p className="text-blue-600 font-semibold text-sm">
                    {formatPrice(product.price)}
                  </p>
                  
                  <div className="flex items-center justify-between mt-2">
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateQuantity(item.product_id, item.quantity - 1)}
                        className="w-8 h-8 p-0"
                      >
                        <Minus className="w-3 h-3" />
                      </Button>
                      
                      <span className="w-8 text-center text-sm font-medium">
                        {item.quantity}
                      </span>
                      
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => updateQuantity(item.product_id, item.quantity + 1)}
                        className="w-8 h-8 p-0"
                      >
                        <Plus className="w-3 h-3" />
                      </Button>
                    </div>
                    
                    <Button
                      size="sm"
                      variant="ghost"
                      onClick={() => handleRemoveItem(item.product_id)}
                      className="text-red-500 hover:text-red-700 p-1"
                    >
                      <Trash2 className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </ScrollArea>

      <div className="mt-6 space-y-4">
        <Separator />
        
        <div className="flex items-center justify-between text-lg font-semibold">
          <span>{t.total}:</span>
          <span className="text-blue-600">{formatPrice(calculateTotal())}</span>
        </div>
        
        <Button
          onClick={handleCheckout}
          disabled={isLoading}
          className="w-full"
          size="lg"
        >
          {isLoading ? (
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
              Processing...
            </div>
          ) : (
            t.checkout
          )}
        </Button>
      </div>
    </div>
  );
}