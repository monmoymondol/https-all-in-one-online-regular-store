import { useState, useEffect } from 'react';
import { Filter, Grid, List, Sparkles, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import Header from '@/components/Header';
import ProductCard from '@/components/ProductCard';
import { 
  initializeData, 
  getProducts, 
  getCategories, 
  searchProducts,
  getProductsByCategory,
  getLanguage,
  type Product, 
  type Category,
  type Language 
} from '@/lib/store';

const translations = {
  en: {
    allCategories: 'All Categories',
    noProducts: 'No products found',
    noProductsDesc: 'Try adjusting your search or filter criteria',
    products: 'Products',
    showing: 'Showing',
    of: 'of',
    featuredProducts: 'Featured Products',
    trendingNow: 'Trending Now',
    clearFilters: 'Clear Filters'
  },
  bn: {
    allCategories: 'সব ক্যাটাগরি',
    noProducts: 'কোন পণ্য পাওয়া যায়নি',
    noProductsDesc: 'আপনার অনুসন্ধান বা ফিল্টার মানদণ্ড সামঞ্জস্য করার চেষ্টা করুন',
    products: 'পণ্য',
    showing: 'দেখানো হচ্ছে',
    of: 'এর মধ্যে',
    featuredProducts: 'বিশেষ পণ্য',
    trendingNow: 'ট্রেন্ডিং এখন',
    clearFilters: 'ফিল্টার পরিষ্কার করুন'
  }
};

export default function Index() {
  const [products, setProducts] = useState<Product[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [filteredProducts, setFilteredProducts] = useState<Product[]>([]);
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [viewMode, setViewMode] = useState<'grid' | 'list'>('grid');
  const [isLoading, setIsLoading] = useState(true);
  const language: Language = getLanguage();
  const t = translations[language];

  useEffect(() => {
    loadData();
  }, []);

  useEffect(() => {
    filterProducts();
  }, [products, selectedCategory, searchQuery]);

  const loadData = async () => {
    try {
      initializeData();
      const productsData = getProducts();
      const categoriesData = getCategories();
      
      setProducts(productsData);
      setCategories(categoriesData);
      setIsLoading(false);
    } catch (error) {
      console.error('Error loading data:', error);
      setIsLoading(false);
    }
  };

  const filterProducts = () => {
    let filtered = products;

    // Apply search filter
    if (searchQuery.trim()) {
      filtered = searchProducts(searchQuery, language);
    }

    // Apply category filter
    if (selectedCategory !== 'all') {
      filtered = filtered.filter(product => product.category_id === selectedCategory);
    }

    setFilteredProducts(filtered);
  };

  const handleSearch = (query: string) => {
    setSearchQuery(query);
  };

  const handleCategoryFilter = (categoryId: string) => {
    setSelectedCategory(categoryId);
  };

  const getCategoryName = (categoryId: string): string => {
    const category = categories.find(cat => cat.id === categoryId);
    if (!category) return '';
    return language === 'en' ? category.name_en : category.name_bn;
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
        <Header onSearch={handleSearch} onCategoryFilter={handleCategoryFilter} />
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center justify-center h-64">
            <div className="flex items-center gap-3">
              <div className="w-8 h-8 border-4 border-blue-600 border-t-transparent rounded-full animate-spin"></div>
              <span className="text-xl text-gray-600 font-medium">Loading amazing products...</span>
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-indigo-50 to-purple-50">
      <Header onSearch={handleSearch} onCategoryFilter={handleCategoryFilter} />
      
      <main className="container mx-auto px-4 py-8">
        {/* Hero Section */}
        <div className="mb-12 text-center">
          <div className="inline-flex items-center gap-2 bg-gradient-to-r from-yellow-400 to-orange-500 text-white px-6 py-2 rounded-full text-sm font-semibold mb-4 shadow-lg">
            <Sparkles className="w-4 h-4" />
            {t.featuredProducts}
          </div>
          <h2 className="text-4xl md:text-5xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-600 bg-clip-text text-transparent mb-4">
            {t.trendingNow}
          </h2>
          <p className="text-gray-600 text-lg max-w-2xl mx-auto">
            Discover amazing products at unbeatable prices with fast delivery
          </p>
        </div>

        {/* Enhanced Filters */}
        <div className="bg-white/70 backdrop-blur-sm rounded-2xl shadow-xl border border-white/20 p-6 mb-8">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="flex items-center gap-4 flex-1">
              <div className="flex items-center gap-2">
                <div className="w-10 h-10 bg-gradient-to-r from-blue-500 to-purple-500 rounded-lg flex items-center justify-center">
                  <Filter className="w-5 h-5 text-white" />
                </div>
                <span className="text-lg font-semibold text-gray-700">Filter Products:</span>
              </div>
              
              <Select value={selectedCategory} onValueChange={setSelectedCategory}>
                <SelectTrigger className="w-64 bg-white/80 border-2 border-blue-200 hover:border-blue-400 transition-colors">
                  <SelectValue placeholder={t.allCategories} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">{t.allCategories}</SelectItem>
                  {categories.map((category) => (
                    <SelectItem key={category.id} value={category.id}>
                      {language === 'en' ? category.name_en : category.name_bn}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-center gap-2">
              <Button
                variant={viewMode === 'grid' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('grid')}
                className="transition-all duration-300"
              >
                <Grid className="w-4 h-4" />
              </Button>
              <Button
                variant={viewMode === 'list' ? 'default' : 'outline'}
                size="sm"
                onClick={() => setViewMode('list')}
                className="transition-all duration-300"
              >
                <List className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>

        {/* Enhanced Results Info */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <TrendingUp className="w-6 h-6 text-blue-600" />
              <h3 className="text-3xl font-bold text-gray-900">{t.products}</h3>
            </div>
            <Badge 
              variant="secondary" 
              className="bg-gradient-to-r from-blue-500 to-purple-500 text-white px-4 py-2 text-sm font-semibold"
            >
              {t.showing} {filteredProducts.length} {t.of} {products.length}
            </Badge>
          </div>
        </div>

        {/* Products Grid */}
        {filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <div className="w-32 h-32 mx-auto mb-6 bg-gradient-to-br from-gray-100 to-gray-200 rounded-full flex items-center justify-center shadow-inner">
              <Grid className="w-12 h-12 text-gray-400" />
            </div>
            <h3 className="text-2xl font-bold text-gray-900 mb-3">{t.noProducts}</h3>
            <p className="text-gray-600 mb-8 max-w-md mx-auto">{t.noProductsDesc}</p>
            <Button 
              variant="default"
              size="lg"
              onClick={() => {
                setSelectedCategory('all');
                setSearchQuery('');
              }}
              className="bg-gradient-to-r from-blue-500 to-purple-500 hover:from-blue-600 hover:to-purple-600 text-white px-8 py-3 rounded-xl shadow-lg transform transition-all duration-300 hover:scale-105"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              {t.clearFilters}
            </Button>
          </div>
        ) : (
          <div className={
            viewMode === 'grid' 
              ? 'grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8'
              : 'grid grid-cols-1 md:grid-cols-2 gap-8'
          }>
            {filteredProducts.map((product) => (
              <div 
                key={product.id}
                className="transform transition-all duration-300 hover:scale-105"
              >
                <ProductCard
                  product={product}
                  categoryName={getCategoryName(product.category_id)}
                />
              </div>
            ))}
          </div>
        )}
      </main>
      
      {/* Decorative Footer */}
      <footer className="mt-20 bg-gradient-to-r from-blue-600 via-purple-600 to-indigo-700 text-white py-8">
        <div className="container mx-auto px-4 text-center">
          <p className="text-lg font-medium opacity-90">
            Thank you for shopping with {t.storeName}
          </p>
          <div className="mt-4 flex justify-center">
            <div className="w-16 h-1 bg-gradient-to-r from-yellow-400 to-orange-500 rounded-full"></div>
          </div>
        </div>
      </footer>
    </div>
  );
}