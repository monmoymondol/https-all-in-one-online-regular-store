import { useState, useEffect } from 'react';
import { Plus, Save, X } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from 'sonner';
import { addProduct, updateProduct, getCategories, getLanguage, type Product, type Category, type Language } from '@/lib/store';

interface AdminProductFormProps {
  product?: Product;
  onSave: () => void;
  onCancel: () => void;
}

const translations = {
  en: {
    addProduct: 'Add New Product',
    editProduct: 'Edit Product',
    productNameEn: 'Product Name (English)',
    productNameBn: 'Product Name (Bangla)',
    descriptionEn: 'Description (English)',
    descriptionBn: 'Description (Bangla)',
    price: 'Price (৳)',
    category: 'Category',
    imageUrl: 'Image URL',
    stock: 'Stock Quantity',
    save: 'Save Product',
    cancel: 'Cancel',
    selectCategory: 'Select Category',
    productAdded: 'Product added successfully!',
    productUpdated: 'Product updated successfully!',
    fillRequired: 'Please fill in all required fields'
  },
  bn: {
    addProduct: 'নতুন পণ্য যোগ করুন',
    editProduct: 'পণ্য সম্পাদনা করুন',
    productNameEn: 'পণ্যের নাম (ইংরেজি)',
    productNameBn: 'পণ্যের নাম (বাংলা)',
    descriptionEn: 'বিবরণ (ইংরেজি)',
    descriptionBn: 'বিবরণ (বাংলা)',
    price: 'দাম (৳)',
    category: 'ক্যাটাগরি',
    imageUrl: 'ছবির URL',
    stock: 'স্টক পরিমাণ',
    save: 'পণ্য সংরক্ষণ করুন',
    cancel: 'বাতিল',
    selectCategory: 'ক্যাটাগরি নির্বাচন করুন',
    productAdded: 'পণ্য সফলভাবে যোগ করা হয়েছে!',
    productUpdated: 'পণ্য সফলভাবে আপডেট করা হয়েছে!',
    fillRequired: 'অনুগ্রহ করে সব প্রয়োজনীয় ক্ষেত্র পূরণ করুন'
  }
};

export default function AdminProductForm({ product, onSave, onCancel }: AdminProductFormProps) {
  const [formData, setFormData] = useState({
    name_en: '',
    name_bn: '',
    description_en: '',
    description_bn: '',
    price: '',
    category_id: '',
    image: '',
    stock: ''
  });
  const [categories, setCategories] = useState<Category[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const language: Language = getLanguage();
  const t = translations[language];

  useEffect(() => {
    setCategories(getCategories());
    
    if (product) {
      setFormData({
        name_en: product.name_en,
        name_bn: product.name_bn,
        description_en: product.description_en,
        description_bn: product.description_bn,
        price: product.price.toString(),
        category_id: product.category_id,
        image: product.image,
        stock: product.stock.toString()
      });
    }
  }, [product]);

  const handleInputChange = (field: string, value: string) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name_en || !formData.name_bn || !formData.price || !formData.category_id) {
      toast.error(t.fillRequired);
      return;
    }

    setIsLoading(true);

    try {
      const productData = {
        name_en: formData.name_en,
        name_bn: formData.name_bn,
        description_en: formData.description_en,
        description_bn: formData.description_bn,
        price: parseFloat(formData.price),
        category_id: formData.category_id,
        image: formData.image || 'https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=400',
        stock: parseInt(formData.stock) || 0
      };

      if (product) {
        updateProduct(product.id, productData);
        toast.success(t.productUpdated);
      } else {
        addProduct(productData);
        toast.success(t.productAdded);
      }

      onSave();
    } catch (error) {
      toast.error('Error saving product');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <Card className="w-full max-w-2xl mx-auto">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Plus className="w-5 h-5" />
          {product ? t.editProduct : t.addProduct}
        </CardTitle>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="name_en">{t.productNameEn} *</Label>
              <Input
                id="name_en"
                value={formData.name_en}
                onChange={(e) => handleInputChange('name_en', e.target.value)}
                placeholder="Enter product name in English"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="name_bn">{t.productNameBn} *</Label>
              <Input
                id="name_bn"
                value={formData.name_bn}
                onChange={(e) => handleInputChange('name_bn', e.target.value)}
                placeholder="পণ্যের নাম বাংলায় লিখুন"
                required
              />
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="price">{t.price} *</Label>
              <Input
                id="price"
                type="number"
                min="0"
                step="0.01"
                value={formData.price}
                onChange={(e) => handleInputChange('price', e.target.value)}
                placeholder="0.00"
                required
              />
            </div>
            
            <div className="space-y-2">
              <Label htmlFor="stock">{t.stock}</Label>
              <Input
                id="stock"
                type="number"
                min="0"
                value={formData.stock}
                onChange={(e) => handleInputChange('stock', e.target.value)}
                placeholder="0"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="category">{t.category} *</Label>
            <Select value={formData.category_id} onValueChange={(value) => handleInputChange('category_id', value)}>
              <SelectTrigger>
                <SelectValue placeholder={t.selectCategory} />
              </SelectTrigger>
              <SelectContent>
                {categories.map((category) => (
                  <SelectItem key={category.id} value={category.id}>
                    {language === 'en' ? category.name_en : category.name_bn}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="image">{t.imageUrl}</Label>
            <Input
              id="image"
              type="url"
              value={formData.image}
              onChange={(e) => handleInputChange('image', e.target.value)}
              placeholder="/images/exampleimage.jpg"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description_en">{t.descriptionEn}</Label>
            <Textarea
              id="description_en"
              value={formData.description_en}
              onChange={(e) => handleInputChange('description_en', e.target.value)}
              placeholder="Enter product description in English"
              rows={3}
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="description_bn">{t.descriptionBn}</Label>
            <Textarea
              id="description_bn"
              value={formData.description_bn}
              onChange={(e) => handleInputChange('description_bn', e.target.value)}
              placeholder="পণ্যের বিবরণ বাংলায় লিখুন"
              rows={3}
            />
          </div>

          <div className="flex gap-4 pt-4">
            <Button type="submit" disabled={isLoading} className="flex-1">
              {isLoading ? (
                <div className="flex items-center gap-2">
                  <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin" />
                  Saving...
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Save className="w-4 h-4" />
                  {t.save}
                </div>
              )}
            </Button>
            
            <Button type="button" variant="outline" onClick={onCancel}>
              <X className="w-4 h-4 mr-2" />
              {t.cancel}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  );
}